package com.axonvibe.demo;

import org.springframework.boot.test.util.TestPropertyValues;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by nththuy on 7/29/19.
 */
public class TestUtils {

    static TestPropertyValues using(PostgreSQLContainer<?> postgresContainer, GenericContainer<?> rabbitContainer) {
        List<String> pairs = new ArrayList<>();

        pairs.add("spring.datasource.url=" + postgresContainer.getJdbcUrl());
        pairs.add("spring.datasource.username=" + postgresContainer.getUsername());
        pairs.add("spring.datasource.password=" + postgresContainer.getPassword());
        pairs.add("spring.rabbitmq.port=" + rabbitContainer.getMappedPort(5672));

        return TestPropertyValues.of(pairs);
    }
}
