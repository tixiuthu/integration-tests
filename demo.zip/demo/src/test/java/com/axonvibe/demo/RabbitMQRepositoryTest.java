package com.axonvibe.demo;

import com.thuy.demo.Notification;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by nththuy on 7/29/19.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(initializers = {RabbitMQRepositoryTest.Initializer.class})
public class RabbitMQRepositoryTest {


    @ClassRule
    public static PostgreSQLContainer<?> sqlContainer = new PostgreSQLContainer<>("postgres:latest");

    @ClassRule
    public static GenericContainer<?> rabbitContainer = new GenericContainer<>("rabbitmq:management")
            .withExposedPorts(5672);

    @Autowired
    private RabbitTemplate rabbitTemplate;


    @Test
    public void receiveNotification() {

        // given
        Notification notification = new Notification("hello world", "local");
        // when
        rabbitTemplate.convertAndSend("demo-exchange", "demo", notification);
        // then
        ParameterizedTypeReference<Notification> notificationTypeRef = new ParameterizedTypeReference<Notification>() {
        };

        Notification expected = rabbitTemplate.receiveAndConvert("demo-queue", 1000, notificationTypeRef);
        assertThat(expected.getMessage(), is("hello world"));
        assertThat(expected.getSource(), is("local"));
        assertThat(expected.getId(), notNullValue());
    }

    static class Initializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
        @Override
        public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
            TestPropertyValues.of(
                    "spring.datasource.url=" + sqlContainer.getJdbcUrl(),
                    "spring.datasource.username=" + sqlContainer.getUsername(),
                    "spring.datasource.password=" + sqlContainer.getPassword(),
                    "spring.rabbitmq.port=" + rabbitContainer.getMappedPort(5672)

            ).applyTo(configurableApplicationContext.getEnvironment());
        }


    }
}
