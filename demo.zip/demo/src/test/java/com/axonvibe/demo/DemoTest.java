package com.axonvibe.demo;

import com.thuy.demo.Notification;
import com.thuy.demo.NotificationRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by nththuy on 7/29/19.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@ContextConfiguration(initializers = {DemoTest.Initializer.class})
public class DemoTest {

    @ClassRule
    public static PostgreSQLContainer<?> postgresContainer = new PostgreSQLContainer<>("postgres:latest");

    @ClassRule
    public static GenericContainer<?> rabbitContainer = new GenericContainer<>("rabbitmq:management")
            .withExposedPorts(5672);

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private static final Logger LOGGER = LogManager.getLogger(DemoTest.class);

    @Test
    public void storeNotification() {

        // given
        LOGGER.info("starting...store  ");
        notificationRepository.save(new Notification("hello world", "local"));

        // when
        LOGGER.info("get row...");
        long count = notificationRepository.count();

        // then
        LOGGER.info("check ... data is exists in db");
        assertThat(count, is(1L));
        System.out.println("done ....");
    }

    @Test
    public void receiveNotification() {

        // given
        LOGGER.info("starting...rabbit ");
        Notification notification = new Notification("hello world", "local");

        // when
        LOGGER.info("...send  ");
        rabbitTemplate.convertAndSend("demo-exchange", "demo", notification);

        // then
        ParameterizedTypeReference<Notification> notificationTypeRef = new ParameterizedTypeReference<Notification>() {
        };
        LOGGER.info("...check  ");
        Notification expected = rabbitTemplate.receiveAndConvert("demo-queue", 1000, notificationTypeRef);
        assertThat(expected.getMessage(), is("hello world"));
        assertThat(expected.getSource(), is("local"));
        assertThat(expected.getId(), notNullValue());
        LOGGER.info("...done  ");
    }

    static class Initializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
            TestUtils.using(postgresContainer, rabbitContainer)
                    .applyTo(configurableApplicationContext.getEnvironment());
        }

    }

}
