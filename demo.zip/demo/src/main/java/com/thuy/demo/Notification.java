package com.thuy.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by nththuy on 7/29/19.
 */

@Entity
@Table(name = "notification")
public class Notification {

    @Id
    private long id;

    private String message;

    private String source;


    public Notification() {
    }

    public long getId() {
        return id;
    }

    public String getMessage() {
        return message;
    }

    public String getSource() {
        return source;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Notification(String message, String source) {
        this.message = message;
        this.source = source;
    }

}
