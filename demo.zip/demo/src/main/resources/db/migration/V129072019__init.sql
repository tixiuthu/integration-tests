CREATE TABLE notification (
    id      serial primary key,
    message text not null,
    source  text not null
);